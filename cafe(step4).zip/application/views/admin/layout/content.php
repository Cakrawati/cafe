<?php
// Memanggil data isi content dari controller variabel ISI
if ($isi) 
{
	$this->load->view($isi);
}
