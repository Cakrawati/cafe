<!-- social bar -->

    <section id="social-bar">
        <div class="wrapper1">
            <div class="row">
                <div class="col-4 box ">
                    <ul class="socialul1">
                        <li id="fbpadleft" class="color1"><a href=""><i class="fab fa-facebook-f color8"></i></a></li>
                                <li><a href=""><i class="fab fa-instagram color8"></i></a></li>
                                <li><a href=""><i class="fab fa-pinterest color8"></i></a></li>
                                <li><a href=""><i class="fab fa-google-plus-g color8"></i></a></li>
                                <li><a href=""><i class="fab fa-youtube color8"></i></a></li>
                    </ul>
                </div>

                <div class="col-5 box color">
                    <h4 class="color1">Free shipping for standard order over $100</h4>
                </div>

                <div class="col-3 box color1">
                    <h4 style="float:right">fashe@example.com</h4>
                </div>
                <div class="clear"></div>
            </div>
        </div>
        <a href="#social-bar" id="up"><i class="fas fa-angle-double-up"></i></a>
    </section>