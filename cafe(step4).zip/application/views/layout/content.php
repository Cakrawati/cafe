<?php
// Mengambil data isi content website di conroller (dari variabel ISI)
if ($isi) 
{
	$this->load->view($isi);
}