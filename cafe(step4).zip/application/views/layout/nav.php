 <!-- header section-->
    <header id="headers">
        <div class="wrapper1">
            <nav>
                <div class="row">
                    <div class="col-3 box-nav line2"><a href=""><img src="<?php echo base_url() ?>assets/template/images/icon.jpg" alt="img" height="75" width="80"></a></div>

                    <div class="col-7 box-nav line1 ">
                        <ul class="navul1">
                            <li><a href="index.html" class="color4">Home</a></li>
                            <li><a href="shop.html" class="color4">Shop</a></li>
                            <li><a href="sale.html" class="color5">Sale</a></li>
                            <li><a href="features.html" class="color4">Features</a></li>
                            <li><a href="blog.html" class="color4">Blog</a></li>
                            <li><a href="about.html" class="color4">About</a></li>
                            <li><a href="contact.html" class="color4">Contact</a></li>
                        </ul>
                    </div>

                    <div class="col-2 box-nav  " style="float:right; padding-top:20px; ">
                            <p>6</p>
                            <a href="">
                                <img src="<?php echo base_url() ?>assets/template/images/icon-header-02.png" style="float:right" alt="">
                            </a>
                            
                            <div style="width:1px;height: 27px;background-color: #C4C4C4;float: right; display: inline-block; margin: 0px 20px; "></div>
                            <a href="">
                                <img src="<?php echo base_url() ?>assets/template/images/icon-header-01.png " style="float:right" alt="">
                                
                            </a>
                        </div>
                <div class="clear"></div>
            </nav>
        </div>
    </header>