<!-- footer -->
    <footer id="footers">
        <div class="wrapper1">
            <div class="row">
                <div class="col-4 box-footer">
                    <h3>GET IN TOUCH</h3>
                    <p>Any questions? Let us know in store at 8th floor, 379 <br>
                         Hudson St, New York, NY 10018 or call us on (+1) 96 716 6879</p>
                        
                         <ul class="foot-social">
                                <li><a href=""><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href=""><i class="fab fa-twitter"></i></a></li>
                                <li><a href=""><i class="fab fa-pinterest"></i></a></li>
                                <li><a href=""><i class="fab fa-google-plus-g"></i></a></li>
                                <li><a href=""><i class="fab fa-youtube "></i></a></li>
                         </ul>
                        </div>
                <div class="col-4 box-footer">
                    <div class="row">
                            <div class="col-4 color12">
                                <ul>
                                    <li><h3>CATEGORIES</h3></li>
                                    <li><a href="">Men</a></li>
                                    <li><a href="">Woman</a></li>
                                    <li><a href="">Dresses</a></li>
                                    <li><a href="">Sunglasses</a></li>
                                </ul>
                            </div>
                            <div class="col-4 color12">
                                    <ul>
                                            <li><h3>LINKS</h3></li>
                                            <li><a href="">Search</a></li>
                                            <li><a href="">Abut Us</a></li>
                                            <li><a href="">Contact Us</a></li>
                                            <li><a href="">Returns</a></li>
                                        </ul>
                            </div>
                            <div class="col-4 color12">
                                    <ul>
                                            <li><h3>HELP</h3></li>
                                            <li><a href="">Track Over</a></li>
                                            <li><a href="">Resturns</a></li>
                                            <li><a href="">Shipping</a></li>
                                            <li><a href="">FAQs</a></li>
                                        </ul>
                            </div>
                    </div>
                </div>
                <div class="col-4 box-footer">
                    <h3>NEWSLETTER</h3>
                    <input class="" type="text" placeholder="email@example.com">
                    <div><button class="subscribe" href="#" title="subscribe">SUBSCRIBE</button></div>
                </div>
            </div>
            <div class="row">
            <div class="col-12 box-footerend">
                <ul class="foot-end-card">
                    <li><a href=""><i class="fab fa-cc-paypal"></i></a></li>
                    <li><a href=""><i class="fab fa-cc-visa"></i></a></li>
                    <li><a href=""><i class="fab fa-cc-mastercard"></i></a></li>
                    <li><a href=""><i class="fab fa-cc-amex"></i></a></li>
                    <li><a href=""><i class="fab fa-cc-amazon-pay"></i></a></li>
                </ul>
                <span>Copyright © 2017 Colorlib. All rights reserved.</span>
            </div>
        </div>
    </footer>



</body>

</html>